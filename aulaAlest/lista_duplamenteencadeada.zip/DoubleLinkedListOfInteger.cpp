#include <iostream>
#include <sstream>
using namespace std;

#include "DoubleLinkedListOfInteger.h"

#define IndexOutOfBoundsException 0

/**
 * Construtor da lista.
 */
DoubleLinkedListOfInteger::DoubleLinkedListOfInteger(){
    header = new Nodo(0);
    trailer = new Nodo(0);
    header->next = trailer;
    trailer->prev = header;
    count = 0;
}

/**
 * Impressão da lista.
 */
void DoubleLinkedListOfInteger::ImprimeLista() {
    Nodo *ptr;
    if (count == 0) {
    // Lista Vazia  
        printf("List: []\n");
        return;
    }
    // Caso a lista nao esteja vazia
    ptr = header->next;
    printf("List: [");
    while (true){
        printf("%d", ptr->element); 
        ptr = ptr->next;
        if (ptr==trailer){
            printf("]\n");
            break;
        } else{
            printf("; ");
        }
    }
}

/**
 * Retorna true se a lista nao contem elementos.
 * @return true se a lista nao contem elementos
 */
bool DoubleLinkedListOfInteger::isEmpty() {
    return (count == 0);
}

/**
 * Retorna o numero de elementos da lista.
 * @return o numero de elementos da lista
 */
int DoubleLinkedListOfInteger::size() {
    return count;
}

/**
 * Esvazia a lista
 */
void DoubleLinkedListOfInteger::clear() {
    Nodo *ptr;
    if (count == 0) {
      // Lista já estava Vazia
      return;
    }
    // Caso a lista nao esteja vazia
    // Apaga cada elemento
    ptr = header->next;
    Nodo *aux;
    while (true) {
        cout << "Apagando " << ptr->element << endl;
        aux = ptr;
        ptr = ptr->next;
        delete aux;
        if (ptr==trailer)
            break;
    }
    header->next = trailer;
    trailer->prev = header;
    count = 0;
}

/**
 * Adiciona um elemento ao final da lista.
 * @param element elemento a ser adicionado ao final da lista
 */
void DoubleLinkedListOfInteger::add(int element) {
    Nodo *novo = new Nodo(element); // cria um novo objeto Nodo, mantendo a referencia à ele em "novo"

    novo->next = trailer; // faz o novo nodo apontar para o nodo sentinela
    novo->prev = trailer->prev; // faz o novo nodo apontar para o ultimo elemento da lista

    novo->prev->next = novo; // faz o ultimo nodo apontar para o novo nodo
    novo->next->prev = novo; // faz o nodo sentinela apontar para o novo nodo
    
    count++;
    return;
}

 /* Retorna a referência ao nodo que está em uma determinada posicao da lista. */
Nodo* DoubleLinkedListOfInteger::getNodeIndex(int index){
    if ((index < 0) || (index >= count)) {
        throw IndexOutOfBoundsException;
    }
    Nodo *ptr;
    if(index > (count/2)){
        ptr = trailer->prev; // aponta para o último elemento da lista
        // retorcede até chegar na posição desejada
        for(int i = count-1; i > index; i++){
            ptr = ptr->prev;
        }
    } else{
        ptr = header->next; // aponta para o primeiro elemento da lista
        // avança até chegar na posição desejada
        for(int i = 0; i < index; i++){
            ptr = ptr->next;
        }
    }
    return ptr;
}

/**
 * Retorna o elemento de uma determinada posicao da lista.
 * @param index a posição da lista
 * @return o elemento da posicao especificada
 * @throws IndexOutOfBoundsException se (index < 0 || index >= size())
 */
int DoubleLinkedListOfInteger::get(int index) {
    if ((index < 0) || (index >= count)) {
        throw IndexOutOfBoundsException;
    }
    
    Nodo *ptr = getNodeIndex(index);
    return ptr->element;
}

/**
 * Insere um elemento em uma determinada posicao da lista.
 * @param index a posicao da lista onde o elemento sera inserido
 * @param element elemento a ser inserido
 * @throws IndexOutOfBoundsException se (index < 0 || index > size())
 */
void DoubleLinkedListOfInteger::add(int index, int element) {
    if ((index < 0) || (index >= count)) {
        throw IndexOutOfBoundsException;
    }
    Nodo *ptr = getNodeIndex(index);
    Nodo *novo = new Nodo(element);

    // faz o novo nodo apontar para os nodos antigos da lista
    novo->next = ptr;
    novo->prev = ptr->prev;

    // faz os nodos antigos apontarem para o novo nodo
    novo->prev->next = novo;
    novo->next->prev = novo;
    
    count++;
    return;
}

/**
 * Substitui o elemento armazenado em uma determinada posicao da lista pelo elemento indicado.
 * @param index a posicao na lista
 * @param element o elemento a ser armazenado na lista
 * @return o elemento armazenado anteriormente na posicao da lista
 * @throws IndexOutOfBoundsException se (index < 0 || index >= size())
 */
int DoubleLinkedListOfInteger::set(int index, int element) {
    if ((index < 0) || (index >= count)) {
        throw IndexOutOfBoundsException;
    }
    Nodo *ptr = getNodeIndex(index); // pega a referencia ao nodo na posicao index
    int retorno = ptr->element; // salva o valor atual para retornar
    ptr->element = element; // faz o set no nodo
    return retorno;
}

/**
  * Remove o elemento de uma determinada posicao da lista.
  * @param index a posicao da lista
  * @return o elemento que foi removido da lista
  * @throws IndexOutOfBoundsException se (index < 0 || index >= size())
  */
int DoubleLinkedListOfInteger::removeByIndex(int index) {
    if ((index < 0) || (index >= count)) {
        throw IndexOutOfBoundsException;
    }
    Nodo *ptr = getNodeIndex(index);
    int retorno = ptr->element;
    ptr->prev->next = ptr->next;
    ptr->next->prev = ptr->prev;
    delete ptr;
    count--;
    return retorno;
}

/**
 * Remove a primeira ocorrencia do elemento na lista, se estiver presente.
 * @param element o elemento a ser removido
 * @return true se a lista contem o elemento especificado
 */
bool DoubleLinkedListOfInteger::remove(int element) {
    // retorna false se a lista estiver vazia
    if (count == 0)
        return false;

    Nodo *ptr = header->next; // aponta para o primeiro elemento da lista
    for(int i = 0; i < count; i++){
        if(ptr->element == element){
            removeByIndex(i);
            return true;
        }
        ptr = ptr->next;
    }
    return false;
}

/**
 * Retorna o indice da primeira ocorrencia do elemento na lista, ou -1 se a
 * lista nao contem o elemento.
 * @param element o elemento a ser buscado
 * @return o indice da primeira ocorrencia do elemento na lista, ou -1 se a
 * lista nao contem o elemento
 */
int DoubleLinkedListOfInteger::indexOf(int element) {
    Nodo *ptr = header->next;
    // avança na lista comparando o element com os elementos armazenados em cada nodo
    // se encontrar, retorna o index (i) atual 
    for(int i = 0; i < count; i++){
        if(element == ptr->element)
            return i;
        ptr = ptr->next;
    }
    return -1;
}

/**
 * Retorna true se a lista contem o elemento especificado.
 * @param element o elemento a ser testado
 * @return true se a lista contem o elemento especificado
 */
bool DoubleLinkedListOfInteger::contains(int element) {
    if (isEmpty())
        return false;  // Lista Vazia

    // utiliza o método anterior para verificar se o element está na lista
    if(indexOf(element) == -1)
        return false;
    else
        return true;
}

/**
 * Retorna um arranjo com os elementos da lista original entre
 * fromIndex (inclusivo) e toIndex (exclusivo).
 * @param fromIndex posicao a partir da qual os elementos serao inseridos no
 * arranjo a ser retornado
 * @param toIndex indica a posicao final dos elementos que devem ser
 * inseridos
 * @return Um arranjo com um subconjunto dos elementos da lista.
 * @throws IndexOutOfBoundsException se (fromIndex < 0 || toIndex > size())
 * @throws IllegalArgumentException se (fromIndex > toIndex)
  */
int* DoubleLinkedListOfInteger::subList(int fromIndex, int toIndex) {
    // Primeiro verifica se os indices sao validos
    if (fromIndex < 0 || toIndex > size() || fromIndex >= toIndex) {
        cout << "Indices invalidos!" << endl;
        throw IndexOutOfBoundsException;
    }

    int *vector = new int[toIndex-fromIndex];
    Nodo *ptr = getNodeIndex(fromIndex);
    for(int i = 0; i < (toIndex-fromIndex); i++){
        vector[i] = ptr->element;
        ptr = ptr->next;
    }

    return vector;
}


void DoubleLinkedListOfInteger::printBackToFront(){
    Nodo *ptr = trailer->prev;
    printf("Reversed: [");
    for(int i = 0; i < count; i++){
        printf("%d", ptr->element);
        if(i != count-1)
            printf("; ");
        ptr = ptr->prev;
    }
    printf("]\n");
    return;
}

void DoubleLinkedListOfInteger::recursivePrintBackToFront(){
    recursivePrintBackToFront(trailer->prev);
}  

void DoubleLinkedListOfInteger::recursivePrintBackToFront(Nodo* n){
    if(n->next == trailer){
        printf("Reversed: [");
    }
    if(n != header){
        printf("%d", n->element);
        if(n->prev != header)
            printf("; ");
    }
    if(n == header){
        printf("]\n");
        return;
    }
    recursivePrintBackToFront(n->prev);
    return;
}

bool DoubleLinkedListOfInteger::equals(DoubleLinkedListOfInteger *l){
    if (this->size() != l->size())
        return false;
    
    Nodo *ptr1, *ptr2;
    ptr1 = header->next;
    ptr2 = l->getNodeIndex(0);
    for(int i = 0; i < this->size(); i++){
        if(ptr1->element != ptr2->element){
            return false;
        }
        ptr1 = ptr1->next;
        ptr2 = ptr2->next;
    }

    return true;
}

void DoubleLinkedListOfInteger::addIncreasingOrder(int element){
    Nodo *ptr = header->next;
    Nodo *novo = new Nodo(element);
    // enquanto o elemento for menor que o que está na lista e não chegarmos no final da lista...
    while(element < ptr->element && ptr->next != trailer){
        ptr = ptr->next;
    }

    // faz o novo nodo apontar para os elementos antigos da lista
    novo->next = ptr;
    novo->prev = ptr->prev;

    // faz os elementos antigos da lista apontarem para o novo
    novo->next->prev = novo;
    novo->prev->next = novo;

    return;
}


bool DoubleLinkedListOfInteger::unique(){
    if(isEmpty())
        return true;

    Nodo *ptri = header->next; // começa no primeiro elemento da lista
    for(int i = 0; i < count; i++){
        Nodo *ptrj = ptri->next; // começa no proximo do nodo a ser verificado
        for(int j = i+1; j < count; j++){
            if(ptri->element == ptrj->element){ // compara se os elementos armazenados são iguais
                return false;
            }
            ptrj = ptrj->next;
        }
        ptri = ptri->next;
    }
    return true;
}

void DoubleLinkedListOfInteger::InsereNaDireita(Nodo *aux, int valor){
    Nodo *novo = new Nodo(valor);
    
    // faz o novo nodo apontar para os nodos já existentes na lista
    novo->prev = aux;
    novo->next = aux->next;

    // faz os nodos antigos apontarem para o novo elemento
    novo->prev->next = novo;
    novo->next->prev = novo;

    count++;

    return;
}

int DoubleLinkedListOfInteger::lastIndexOf(int element){
    if(isEmpty()){
        return -1;
    }
    Nodo *ptr = trailer->prev;
    for(int i = count-1; i >= 0; i--){
        if(ptr->element == element){
            return i;
        }
        ptr = ptr->prev;
    }
    return -1;
}
