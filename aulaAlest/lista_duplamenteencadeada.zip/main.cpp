#include <iostream>
#include <cstdlib>
using namespace std;

#include "Nodo.h"
#include "DoubleLinkedListOfInteger.h"


int main() {

    DoubleLinkedListOfInteger L1, L2;

    L1.add(1);
    L1.add(2);
    L1.add(30);
    L1.add(3);
    L1.add(1);
    
    cout << "Ultima Ocorrencia: " << L1.lastIndexOf(1) << endl;
    L1.printBackToFront();
    
    L2.add(-2);
    L2.add(3);
    L2.add(30);
    L2.add(20);
    L2.recursivePrintBackToFront();

    cout << "As listas sao iguais? " << L1.equals(&L2) << endl;    

    cout << "A lista L1 e unique? " << L1.unique() << endl;

    cout << "A lista L2 e unique? " << L2.unique() << endl; 

    cout << "O ultimo index do elemento 1 na lista L1 e: " << L1.lastIndexOf(1) << endl;

    cout << "O primeiro index do elemento 1 na lista L1 e: " << L1.indexOf(1) << endl;

    cout << "O primeiro index do elemento 30 na lista L1 e: " << L1.indexOf(30) << endl;

    cout << "O ultimo index do elemento 30 na lista L1 e: " << L1.lastIndexOf(30) << endl;

    L2.ImprimeLista();
    cout << "inserindo -1 a direita de 30..." << endl;
    L2.InsereNaDireita(L2.getNodeIndex(2), -1);
    L2.ImprimeLista();

  return 0;
}
